<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index_entry extends CI_Controller {
	public function index()
	{
		$this->load->view('student_entry');
	}
}
