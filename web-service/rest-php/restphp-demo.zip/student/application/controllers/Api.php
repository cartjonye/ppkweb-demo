<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Api extends REST_Controller
{
	public function __construct($config = 'rest')
	{
		parent::__construct($config);
		$this->load->model('student');
	}

	public function students_post()
	{
		$data = $this->post();
		$res = $this->student->add_student($data);


		$this->response($res);
	}

	public function students_put(string $id = null)
	{
		if ($id === null) {
			$res = ['error' => 'put method requires student id'];
		} else {
			$data = $this->put();
			$data['id'] = $id;
			$res = $this->student->put_student($data);
		}

		$this->response($res);
	}

	public function students_get(string $query = null)
	{
		$byname = $this->query('q');

		if($query === null && $byname === null){
			$res = $this->student->get_all_students();
		}
		else if ($query === null){
			$res = $this->student->get_students_by_name($byname);
		}
		else {
			$res = $this->student->get_students_by_id($query, true);
		}


		$this->response($res);
	}

	public function students_delete(string $id = null)
	{
		if ($id === null) {
			$res = ['error' => 'delete method requires student id'];
		} else {
			$res = $this->student->delete_student($id);
		}

		$this->response($res);
	}

	public function index_get()
	{
		$this->response(['hello' => 'w']);
	}
}
