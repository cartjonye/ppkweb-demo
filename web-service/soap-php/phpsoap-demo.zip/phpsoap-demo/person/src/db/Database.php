<?php

class Database
{

  private static $_instance;
  private $_pdo;

  private function __construct()
  {
    $this->_pdo = new PDO("pgsql:host=nggakbolehtahu.xd;port=5432;dbname=pokoknyaitulah;", "namasaya", "katakuncisaya");
  }

  public static function getInstance()
  {
    if (!self::$_instance) {
      self::$_instance = new self();
    }
    return self::$_instance;
  }

  public function getPDO()
  {
    return $this->_pdo;
  }

  public function getAllPerson()
  {
    $stmt = $this->_pdo->query("SELECT * FROM person ORDER BY id");
    $stmt->execute();
    return $stmt->fetchAll();
  }

  public function getPersonById($id)
  {
    if (!is_int($id)) {
      return null;
    }

    $stmt = $this->_pdo->prepare("SELECT * FROM person WHERE id = ? ORDER BY id");
    $stmt->execute([(int)$id]);
    return $stmt->fetchAll();
  }

  public function getPeopleByNameQuery($name)
  {
    $stmt = $this->_pdo->prepare("SELECT * FROM person WHERE name ILIKE ? ORDER BY id");
    $stmt->execute(["%$name%"]);
    return $stmt->fetchAll();
  }

  public function addPerson($id, $name)
  {
    if (!is_int($id)) {
      return false;
    }

    $stmt = $this->_pdo->prepare("INSERT INTO person VALUES (?, ?)");
    return $stmt->execute([(int)$id, $name]);
  }

  public function deletePersonById($id)
  {
    if (!is_int($id)) {
      return false;
    }

    $stmt = $this->_pdo->prepare("DELETE FROM person WHERE id = ?");
    return $stmt->execute([(int)$id]);
  }

  public function updatePersonNameById($id, $name)
  {
    if (!is_int($id)) {
      return false;
    }

    $stmt = $this->_pdo->prepare("UPDATE person SET name = ? WHERE id = ?");
    return $stmt->execute([$name, (int)$id]);
  }


}

?>