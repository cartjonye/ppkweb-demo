
function editOps(id, name){
  document.getElementById('block').hidden = false;
  document.getElementById('editPopup').hidden = false;
  document.getElementById('edit-id-label').innerText = id;
  document.getElementById('edit-name-label').innerText = name;
  document.getElementById('edit-id').value = id;
  document.getElementById('edit-name').value = name;
}

function deleteOps(id, name){
  document.getElementById('block').hidden = false;
  document.getElementById('deletePopup').hidden = false;
  document.getElementById('delete-id-label').innerText = id;
  document.getElementById('delete-name-label').innerText = name;
  document.getElementById('delete-id').value = id;
}

function hidePopup(){
  document.getElementById('editPopup').hidden = true;
  document.getElementById('deletePopup').hidden = true;
  document.getElementById('block').hidden = true;
}

window.addEventListener('load', function(){
  var edits = document.getElementsByClassName('edit-button');
  for(var i = 0; i < edits.length ; i++){
    edits[i].addEventListener('click', function(){
      var name = this.parentElement.parentElement.parentElement.parentElement.getElementsByClassName('name-col')[0].innerText;
      var id = this.parentElement.parentElement.parentElement.parentElement.getElementsByClassName('id-col')[0].innerText;
      editOps(id, name);
    })
  }

  var deletes = document.getElementsByClassName('delete-button');
  for(var i = 0; i < deletes.length ; i++){
    deletes[i].addEventListener('click', function(){
      var name = this.parentElement.parentElement.parentElement.parentElement.getElementsByClassName('name-col')[0].innerText;
      var id = this.parentElement.parentElement.parentElement.parentElement.getElementsByClassName('id-col')[0].innerText;
      deleteOps(id, name);
    })
  }

  document.getElementById('cancel-delete').addEventListener('click', hidePopup);
  document.getElementById('cancel-edit').addEventListener('click', hidePopup);
})