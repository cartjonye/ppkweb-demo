package com.cartjonye.sloth;

import java.sql.*;
import java.util.*;
public class PersonDatabase {
    private static PersonDatabase instance;
    private Connection connection;
    private final Properties connProperties;
    
    private PersonDatabase() throws SQLException{
        try {
            Class dbDriver = Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        connProperties = new Properties();
        connProperties.setProperty("port", "5432");
        connProperties.setProperty("user", "user");
        connProperties.setProperty("password", "passeword");
        connProperties.setProperty("sslmode", "require");
        getConnection();
    }
    
    private Connection getConnection() throws SQLException{
        
        if (connection == null) {
            connection = DriverManager.getConnection(
                    "jdbc:postgresql://notlocalhost:5432/your_db",
                    connProperties
            );
        }
        return connection;
    }
    
    public static synchronized PersonDatabase getInstance() throws SQLException{
        if(instance == null){
            instance = new PersonDatabase();
        }
        return instance;
    }
    
    public ArrayList<PersonEntity> getPeople() throws SQLException{
        ArrayList<PersonEntity> people = new ArrayList<>();
        
        ResultSet rs = getConnection().createStatement().executeQuery("SELECT * FROM person");
        while(rs.next()){
            PersonEntity p = new PersonEntity();
            p.setId(rs.getInt("id"));
            p.setName(rs.getString("name"));
            people.add(p);
        }
        
        return people;
    }
    
    public PersonEntity getPersonFromId(int id) throws SQLException{
        PersonEntity person = null;
        
        try (PreparedStatement ps = getConnection().prepareStatement("SELECT name FROM person WHERE id = ?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                person = new PersonEntity();
                person.setName(rs.getString("name"));
                person.setId(id);
            }
        }
        return person;
    }
    
    public ArrayList<PersonEntity> getPeopleFromNameQuery(String name) throws SQLException{
        ArrayList<PersonEntity> people = new ArrayList<>();
        
        try (PreparedStatement ps = getConnection().prepareStatement("SELECT * FROM person WHERE name LIKE ?")) {
            ps.setString(1, "%" +name + "%");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                PersonEntity pe = new PersonEntity();
                pe.setId(rs.getInt("id"));
                pe.setName(rs.getString("name"));
                people.add(pe);
            }
        }
        return people;
    }
    
    public boolean updatePersonNameById(int id, String name) throws SQLException{
        if (id < 1) {
            return false;
        }
        
        boolean success = false;
        
        try (PreparedStatement ps = getConnection().prepareStatement("UPDATE person SET name = ? WHERE id = ?")){
            ps.setString(1, name);
            ps.setInt(2, id);
            if(ps.executeUpdate() != 0){
                success = true;
            }
        }
        return success;
        
    }
    
    public boolean deletePersonById(int id) throws SQLException{
        if (id < 1) {
            return false;
        }
        
        boolean success = false;
        
        try (PreparedStatement ps = getConnection().prepareStatement("DELETE FROM person WHERE id = ?")) {
            ps.setInt(1, id);
            if(ps.executeUpdate() != 0){
                success = true;
            }
        }
        return success;
    }
    
    public boolean addPerson(int id, String name) throws SQLException{
        if (id < 1 || name.length() < 1){
            return false;
        }
        
        boolean success = false;
        
        try (PreparedStatement ps = getConnection().prepareStatement("INSERT INTO person VALUES(?, ?)")) {
            ps.setInt(1, id);
            ps.setString(2, name);
            if(ps.executeUpdate() != 0){
                success = true;
            }
        }
        return success;
    }
    
    public boolean addPerson(PersonEntity person) throws SQLException {
        if(person == null) {
            return false;
        }
        return addPerson(person.getId(), person.getName());
    }
    
    
}
