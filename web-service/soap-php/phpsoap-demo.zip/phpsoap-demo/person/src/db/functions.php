<?php

require_once 'src/db/Database.php';


function getAllPerson()
{
  return Database::getInstance()->getAllPerson();
}

function getPeopleByNameQuery($name)
{
  return Database::getInstance()->getPeopleByNameQuery($name);
}

function getPersonById($id)
{
  return Database::getInstance()->getPersonById((int)$id);
}

function deletePersonById($id)
{
  return Database::getInstance()->deletePersonById((int)$id);
}

function addPerson($id, $name)
{
  return Database::getInstance()->addPerson((int)$id, $name);
}

function updatePersonNameById($id, $name)
{
  return Database::getInstance()->updatePersonNameById((int)$id, $name);
}
