/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cartjonye.sloth;

import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;

/**
 *
 * @author cartjonye
 */
@WebService(serviceName = "person")
public class person {
    /**
     * Get a person entity by id parameter
     * @param id
     * @return A PersonEntity object
     */
    @WebMethod(operationName = "getPersonById")
    @WebResult(name = "person")
    public PersonEntity getPersonById(@WebParam(name = "id") int id) {
        PersonEntity person = null;
        
        try {
            person = PersonDatabase.getInstance().getPersonFromId(id);
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        return person;
    }

    /**
     * Add a person info into the database using string parameter
     * @param id
     * @param name
     * @return Will return "200 Ok" on success
     */
    @WebMethod(operationName = "addPersonString")
    @WebResult(name = "status")
    public String addPersonString(@WebParam(name = "id") int id, @WebParam(name = "name") String name) {
        String res = "501 Error";
        
        try {
            boolean status = PersonDatabase.getInstance().addPerson(id, name);
            if (status){
                res = "200 Ok";                
            }

        } catch (SQLException ex) {
            res = ex.getMessage();
        }
        
        return res;
    }

    /**
     * Get all of person info from database
     * @return A list containing zero or more PersonEntity object(s)
     */
    @WebMethod(operationName = "getPeople")
    @WebResult(name = "person")
    public ArrayList<PersonEntity> getPeople() {
        ArrayList<PersonEntity> result;
        try {
            result = PersonDatabase.getInstance().getPeople();
        } catch (SQLException ex) {
            result = new ArrayList<>();
        }
        
        return result;
    }

    /**
     * Get all of person info that its name contains the query
     * @param name query
     * @return A list containing zero or more PersonEntity object(s)
     */
    @WebMethod(operationName = "getPeopleByNameQuery")
    @WebResult(name = "person")
    public ArrayList<PersonEntity> getPeopleByNameQuery(@WebParam(name = "name") String name) {
        ArrayList<PersonEntity> result;
        try {
            result = PersonDatabase.getInstance().getPeopleFromNameQuery(name);
        } catch (SQLException ex) {
            result = new ArrayList<>();
        }
        
        return result;
    }

    /**
     * Delete a person from the database that match the id
     * @param id
     * @return Will return "200 Ok" on success
     */
    @WebMethod(operationName = "deletePersonById")
    @WebResult(name = "status")
    public String deletePersonById(@WebParam(name = "id") int id) {
        String res = "501 Error";
        
        try {
            boolean status = PersonDatabase.getInstance().deletePersonById(id);
            if (status){
                res = "200 Ok";                
            }

        } catch (SQLException ex) {
            res = ex.getMessage();
        }
        
        return res;
    }

    /**
     * Update a person's name that match with the id
     * @param id
     * @param name
     * @return Will return "200 Ok" on success
     */
    @WebMethod(operationName = "updatePersonNameById")
    @WebResult(name = "status")
    public String updatePersonNameById(@WebParam(name = "id") int id, @WebParam(name = "name") String name) {
        String res = "501 Error";
        
        try {
            boolean status = PersonDatabase.getInstance().updatePersonNameById(id, name);
            if (status){
                res = "200 Ok";                
            }

        } catch (SQLException ex) {
            res = ex.getMessage();
        }
        
        return res;
    }

    /**
     * Add a person info into the database using a PersonEntity object
     * @param person PersonEntity object
     * @return Will return "200 Ok" on success
     */
    @WebMethod(operationName = "addPerson")
    @WebResult(name = "status")
    public String addPerson(@WebParam(name = "person") PersonEntity person) {
        if (person == null){
            return "501 Error";
        }
        return addPersonString(person.getId(), person.getName());
    }
}
