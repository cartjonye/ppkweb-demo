<?php
require_once 'lib/nusoap.php';

function getSoapClient()
{
  if (!isset($GLOBALS['soapclient'])) {
    
    $GLOBALS['soapclient'] = new nusoap_client('https://wrath.cartjonye.com/person/index.php?wsdl', true);
    $GLOBALS['soapclient']->setEndpoint('https://wrath.cartjonye.com/person/index.php');

  }

  return $GLOBALS['soapclient'];
}

function statusMenu()
{
  if (isset($_GET['query'])) {
    return '<a href="./client.php">(Show all people)</a> Search result of "' . htmlspecialchars($_GET['query']) . '"   ';
  }
  return 'Displayed all person';
}

function showData()
{
  $res = [];
  $html = '';
  $soapclient = getSoapClient();

  if (isset($_GET['query'])) {
    $res = $soapclient->call('getPeopleByNameQuery', ['name' => $_GET['query']]);
  } else {
    $res = $soapclient->call('getAllPerson');
  }

  foreach ($res as $val) {
    $html .= '<tr>';
    $html .= '<td class="id-col">' . $val['id'] . '</td>';
    $html .= '<td class="name-col">' . $val['name'] . '</td>';
    $html .=
      '<td class="action-col"><div class="row">' .
      '<div class="grid-half"><button class="btn active edit-button btn-block">Edit</button></div>' .
      '<div class="grid-half"><button class="btn warn delete-button btn-block">Delete</button></div>' .
      '</div></td>';

    $html .= '</tr>';
  }

  return $html;
}

function searchBar()
{
  if (isset($_GET['query'])) {
    return htmlspecialchars($_GET['query']);
  }
  return '';
}

function insertStatus()
{
  if (!isset($_POST['insert-person-id']) && !isset($_POST['insert-person-name'])) {
    return '';
  }

  if (!isset($_POST['insert-person-id']) || !isset($_POST['insert-person-name'])) {
    return 'Please check the insert input';
  }

  if (!ctype_digit($_POST['insert-person-id'])) {
    return 'Id is not an integer';
  }

  $_POST['insert-person-id'] = (int)$_POST['insert-person-id'];


  $soapclient = getSoapClient();
  $arr = $soapclient->call('addPerson', ['id' => $_POST['insert-person-id'], 'name' => $_POST['insert-person-name']]);
  if (!$arr) {
    return 'Error when insert id = ' . htmlspecialchars($_POST['insert-person-id']);
  }

  $_GET['query'] = $_POST['insert-person-name'];

  return 'Insert id = ' . htmlspecialchars($_POST['insert-person-id']) . ' is successful';
}

function deleteStatus()
{
  if (!isset($_POST['delete-id'])) {
    return '';
  }

  if (!ctype_digit($_POST['delete-id'])) {
    return 'Delete id is not an integer';
  }

  $_POST['delete-id'] = (int)$_POST['delete-id'];

  $soapclient = getSoapClient();
  $arr = $soapclient->call('deletePersonById', ['id' => $_POST['delete-id']]);
  if (!$arr) {
    return 'Error when delete id = ' . htmlspecialchars($_POST['delete-id']);
  }

  unset($_GET['query']);

  return 'Delete id = ' . htmlspecialchars($_POST['delete-id']) . ' is successful';
}

function editStatus()
{
  if (!isset($_POST['edit-id']) && !isset($_POST['edit-name'])) {
    return '';
  }

  if (!isset($_POST['edit-id']) || !isset($_POST['edit-name'])) {
    return 'Edit parameter is missing';
  }

  if (!ctype_digit($_POST['edit-id'])) {
    return 'Edit id is not an integer';
  }

  $_POST['edit-id'] = (int)$_POST['edit-id'];

  $soapclient = getSoapClient();
  $arr = $soapclient->call('updatePersonNameById', ['id' => $_POST['edit-id'], 'name' => $_POST['edit-name']]);
  if (!$arr) {
    return 'Error when update id = ' . htmlspecialchars($_POST['edit-id']);
  }

  $_GET['query'] = $_POST['edit-name'];

  return 'Update id = ' . htmlspecialchars($_POST['edit-id']) . ' is successful';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="../kraken.min.css">
  <link rel="stylesheet" href="../main.css">
  <script src="client.js" defer></script>
  <title>Person Client Sample</title>
</head>

<body>
  <div id="block" hidden="hidden"></div>
  <div id="deletePopup" hidden="hidden">
    <form action="" method="post">
      <fieldset>
        <legend>DELETE PERSON ("<span id='delete-name-label'></span>"  id = <span id='delete-id-label'></span>)</legend>
        <label for="delete-id">Are you sure want to delete?</label>
        <br><br>
        <input type="text" name="delete-id" id="delete-id" hidden="hidden">
        <div class="row">
          <div class="grid-fourth offset-half">
            <input type="submit" class="btn active warn" value="Delete">
          </div>
          <div class="grid-fourth">
            <button class="btn btn-secondary active btn-block" id="cancel-delete" type="button">Cancel</button>
          </div>
        </div>
      </fieldset>
    </form>
  </div>
  <div id="editPopup" hidden="hidden">
    <form action="" method="post">
      <fieldset>
        <legend>EDIT NAME ("<span id='edit-name-label'></span>"  id = <span id='edit-id-label'></span>)</legend>
        <label for="edit-name">New Name:</label>
        <input type="text" name="edit-id" id="edit-id" hidden="hidden">
        <input type="text" name="edit-name" id="edit-name">
        <div class="row">
          <div class="grid-fourth offset-half">
            <input type="submit" class="btn active" value="Edit name">
          </div>
          <div class="grid-fourth">
            <button class="btn btn-secondary active btn-block" id="cancel-edit" type="button">Cancel</button>
          </div>
        </div>    
      </fieldset>
    </form>
  </div>
  <div class="container margin-top">
    <h1 class="no-margin-bottom">"Person" SOAP Client Sample</h1>
      <span>
        Endpoint : <a href="./index.php">Person</a>
      </span>
      <hr/>
    <div class="row">
      <div class="grid-fourth">
        <form action="" method="get">
          <fieldset>
            <legend>Search People</legend>
            <label for="query">Query : </label>
            <input type="text" name="query" id="get-people-query" value="<?php echo searchBar() ?>">
            <input type="submit" class="btn active" value="Submit Query">
          </fieldset>
        </form>
        <hr>
        <form action="" method="post">
          <fieldset>
            <legend>Insert New Person</legend>

            <label for="insert-person-id">New Person id: </label>
            <input type="text" name="insert-person-id" id="insert-person-id">
            <label for="insert-person-name">New Person Name: </label>
            <input type="text" name="insert-person-name" id="insert-person-name">

            <input type="submit" class="btn active" value="Insert New Person">

          </fieldset>
        </form>
      </div>
      <div class="grid-three-fourth">
        <div><span><?php echo insertStatus() ?></span></div>
        <div><span><?php echo editStatus() ?></span></div>
        <div><span><?php echo deleteStatus() ?></span></div>
        <div><span><?php echo statusMenu() ?> </span></div>
        <div class="data-table-wrapper">
          <table class="table-striped table-condensed data-table">
            <thead>
              <tr>
                <th class="id-col">Id</th>
                <th class="name-col">Name</th>
                <th class="action-col">Action</th>
              </tr>          
            </thead>  
            <tbody>
              <?php echo showData() ?>          
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>
</body>

</html>