<?php

require_once 'lib/nusoap.php';
require_once 'src/db/functions.php';

$serv = new nusoap_server();
$serv->configureWSDL('Person', 'urn:person');

$serv->wsdl->addComplexType(
    'Person',
    'complexType',
    'struct',
    'all',
    '',
    [
        'id' => ['name' => 'id', 'type' => 'xsd:int'],
        'name' => ['name' => 'name', 'type' => 'xsd:string']
    ]
);

$serv->wsdl->addComplexType(
    'People',
    'complexType',
    'array',
    '',
    'SOAP-ENC:Array',
    [],
    [
        [
            'ref' => 'SOAP-ENC:arrayType',
            'wsdl:arrayType' => 'tns:Person[]'
        ]
    ],
    'tns:Person'
);

$serv->wsdl->addComplexType(
    'Person',
    'complexType',
    'struct',
    'all',
    '',
    [
        'id' => ['name' => 'id', 'type' => 'xsd:int'],
        'name' => ['name' => 'name', 'type' => 'xsd:string']
    ]
);

$serv->wsdl->addComplexType(
    'People',
    'complexType',
    'array',
    '',
    'SOAP-ENC:Array',
    [],
    [
        [
            'ref' => 'SOAP-ENC:arrayType',
            'wsdl:arrayType' => 'tns:Person[]'
        ]
    ],
    'tns:Person'
);

$serv->register(
    'getAllPerson',
    [],
    ['return' => 'tns:People'],
    'urn:person',
    'urn:person#getAllPerson',
    'rpc',
    'encoded'
);

$serv->register(
    'getPersonById',
    ['id' => 'xsd:int'],
    ['return' => 'tns:People'],
    'urn:person',
    'urn:person#getPersonById',
    'rpc',
    'encoded'
);

$serv->register(
    'getPeopleByNameQuery',
    ['name' => 'xsd:string'],
    ['return' => 'tns:People'],
    'urn:person',
    'urn:person#getPeopleByNameQuery',
    'rpc',
    'encoded'
);

$serv->register(
    'addPerson',
    ['id' => 'xsd:int', 'name' => 'xsd:string'],
    ['return' => 'xsd:boolean'],
    'urn:person',
    'urn:person#addPerson',
    'rpc',
    'encoded'
);

$serv->register(
    'deletePersonById',
    ['id' => 'xsd:int'],
    ['return' => 'xsd:boolean'],
    'urn:person',
    'urn:person#deletePersonById',
    'rpc',
    'encoded'
);

$serv->register(
    'updatePersonNameById',
    ['id' => 'xsd:int', 'name' => 'xsd:string'],
    ['return' => 'xsd:boolean'],
    'urn:person',
    'urn:person#updatePersonNameById',
    'rpc',
    'encoded'
);

$serv->service(file_get_contents('php://input'));
